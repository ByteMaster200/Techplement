function loadHeaderAndFooter() {
    fetch('header-footer.html')
        .then(response => response.text())
        .then(data => {
            document.getElementById('header').innerHTML = new DOMParser().parseFromString(data, 'text/html').querySelector('.header-container').innerHTML;
            document.getElementById('footer').innerHTML = new DOMParser().parseFromString(data, 'text/html').querySelector('.footer-container').innerHTML;
        });
}

function exploreCourses() {
    window.location.href = 'courses.html';
}

document.addEventListener('DOMContentLoaded', function () {
    loadHeaderAndFooter();

    if (document.getElementById('course-list')) {
        loadCourses();
    }

    if (document.getElementById('course-details')) {
        loadCourseDetails();
    }

    if (document.getElementById('signin-form')) {
        document.getElementById('signin-form').addEventListener('submit', function (event) {
            event.preventDefault();
            signIn();
        });
    }
});

function loadCourses() {
    const courses = [
        { id: 1, title: 'Web Development', description: 'Learn the basics of web development. We cover HTML, CSS, and JavaScript to build responsive and interactive websites.', price: 5000 },
        { id: 2, title: 'Data Science', description: 'An introduction to data science, covering data analysis, visualization, and machine learning using Python and R.', price: 7000 },
        { id: 3, title: 'Machine Learning', description: 'Get started with machine learning. Learn the fundamentals of supervised and unsupervised learning algorithms.', price: 8000 },
        { id: 4, title: 'Cyber Security', description: 'Understand the principles of cyber security. Learn how to protect systems, networks, and data.', price: 7500 },
        { id: 5, title: 'Digital Marketing', description: 'Learn digital marketing strategies. Explore SEO, SEM, content marketing, and social media marketing.', price: 6500 },
        { id: 6, title: 'Graphic Design', description: 'Explore the world of graphic design. Learn to use tools like Photoshop and Illustrator to create stunning visuals.', price: 6000 },
        { id: 7, title: 'Mobile App Development', description: 'Develop mobile applications for Android and iOS. Learn the basics of Kotlin, Swift, and cross-platform development.', price: 9000 },
        { id: 8, title: 'Artificial Intelligence', description: 'Dive into AI. Understand neural networks, natural language processing, and computer vision.', price: 10000 },
        { id: 9, title: 'Blockchain Technology', description: 'Discover the fundamentals of blockchain technology and its applications in various industries.', price: 9500 },
        { id: 10, title: 'Cloud Computing', description: 'Learn about cloud computing services and architecture. Explore AWS, Azure, and Google Cloud Platform.', price: 8500 },
        { id: 11, title: 'Project Management', description: 'Master the principles of project management. Learn about Agile, Scrum, and other project management methodologies.', price: 7000 },
        { id: 12, title: 'Business Analytics', description: 'Analyze business data to make informed decisions. Learn about data mining, modeling, and predictive analytics.', price: 8000 },
        { id: 13, title: 'Content Writing', description: 'Enhance your writing skills. Learn about different styles of writing, content creation, and editing.', price: 5500 },
        { id: 14, title: 'UI/UX Design', description: 'Create user-friendly interfaces and improve user experience. Learn about design principles, wireframing, and prototyping.', price: 6000 },
        { id: 15, title: 'Game Development', description: 'Develop interactive games. Learn about game design, Unity, Unreal Engine, and game programming.', price: 9500 },
    ];

    const courseList = document.getElementById('course-list');
    courses.forEach(course => {
        const courseItem = document.createElement('div');
        courseItem.classList.add('course-item');
        courseItem.innerHTML = `<h3>${course.title}</h3><p>${course.description}</p><p><strong>Price:</strong> ₹${course.price}</p><button onclick="viewCourse(${course.id})">View Details</button>`;
        courseList.appendChild(courseItem);
    });
}

function loadCourseDetails() {
    const urlParams = new URLSearchParams(window.location.search);
    const courseId = urlParams.get('id');

    const courses = [
        { id: 1, title: 'Web Development', description: 'Learn the basics of web development.', content: 'This is a detailed description of the Web Development course. You will learn HTML, CSS, and JavaScript, along with frameworks like React and Angular.', price: 5000 },
        { id: 2, title: 'Data Science', description: 'An introduction to data science.', content: 'This is a detailed description of the Data Science course. You will cover topics like data analysis, data visualization, and machine learning using Python and R.', price: 7000 },
        { id: 3, title: 'Machine Learning', description: 'Get started with machine learning.', content: 'This is a detailed description of the Machine Learning course. Learn about supervised and unsupervised learning, neural networks, and deep learning.', price: 8000 },
        { id: 4, title: 'Cyber Security', description: 'Understand the principles of cyber security.', content: 'This is a detailed description of the Cyber Security course. You will learn about network security, cryptography, and ethical hacking.', price: 7500 },
        { id: 5, title: 'Digital Marketing', description: 'Learn digital marketing strategies.', content: 'This is a detailed description of the Digital Marketing course. You will explore SEO, SEM, content marketing, and social media marketing.', price: 6500 },
        { id: 6, title: 'Graphic Design', description: 'Explore the world of graphic design.', content: 'This is a detailed description of the Graphic Design course. Learn to use tools like Photoshop, Illustrator, and InDesign to create stunning visuals.', price: 6000 },
        { id: 7, title: 'Mobile App Development', description: 'Develop mobile applications for Android and iOS.', content: 'This is a detailed description of the Mobile App Development course. Learn about Kotlin, Swift, and cross-platform development with Flutter and React Native.', price: 9000 },
        { id: 8, title: 'Artificial Intelligence', description: 'Dive into AI.', content: 'This is a detailed description of the Artificial Intelligence course. Understand neural networks, natural language processing, and computer vision.', price: 10000 },
        { id: 9, title: 'Blockchain Technology', description: 'Discover the fundamentals of blockchain technology.', content: 'This is a detailed description of the Blockchain Technology course. Learn about decentralized applications, smart contracts, and cryptocurrency.', price: 9500 },
        { id: 10, title: 'Cloud Computing', description: 'Learn about cloud computing services.', content: 'This is a detailed description of the Cloud Computing course. Explore services and architecture of AWS, Azure, and Google Cloud Platform.', price: 8500 },
        { id: 11, title: 'Project Management', description: 'Master the principles of project management.', content: 'This is a detailed description of the Project Management course. Learn about Agile, Scrum, Waterfall, and other project management methodologies.', price: 7000 },
        { id: 12, title: 'Business Analytics', description: 'Analyze business data to make informed decisions.', content: 'This is a detailed description of the Business Analytics course. Learn about data mining, modeling, and predictive analytics.', price: 8000 },
        { id: 13, title: 'Content Writing', description: 'Enhance your writing skills.', content: 'This is a detailed description of the Content Writing course. Learn about different styles of writing, content creation, and editing.', price: 5500 },
        { id: 14, title: 'UI/UX Design', description: 'Create user-friendly interfaces and improve user experience.', content: 'This is a detailed description of the UI/UX Design course. Learn about design principles, wireframing, and prototyping.', price: 6000 },
        { id: 15, title: 'Game Development', description: 'Develop interactive games.', content: 'This is a detailed description of the Game Development course. Learn about game design, Unity, Unreal Engine, and game programming.', price: 9500 },
    ];

    const course = courses.find(c => c.id === parseInt(courseId));
    if (course) {
        const courseDetails = document.getElementById('course-details');
        courseDetails.innerHTML = `<h2>${course.title}</h2><p>${course.content}</p><p><strong>Price:</strong> ₹${course.price}</p><button class="btn btn-primary" onclick="proceedToPayment(${course.id})">Proceed to Payment</button>`;
    }
}

function signIn() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    alert(`Signed in with email: ${email}`);
}

function viewCourse(id) {
    window.location.href = `course-details.html?id=${id}`;
}

function proceedToPayment(courseId) {
    window.location.href = `payment.html?id=${courseId}`;
}
